#pragma once

#include <d3d11.h>
#include <DirectXMath.h>
#include "Graphics/RenderContext/RenderContext.h"
#include "Graphics/Model/Model.h"

class Shader
{
public:
	Shader() {}
	virtual ~Shader() {}

	// �`��J�n
	virtual void Begin(ID3D11DeviceContext* dc, const RenderContext& rc) = 0;

	// �`��
	//virtual void Draw(ID3D11DeviceContext* dc, const Model* model) = 0;

	virtual void Draw(ID3D11DeviceContext* dc, const Model* model, float dissolve_threshold) = 0;//(�}�X�N�p�����ǉ�)

	//virtual void Draw(ID3D11DeviceContext* dc, const std::unique_ptr<Model> model, float dissolve_threshold) = 0;//(�}�X�N�p�����ǉ�)

	// �`��I��
	virtual void End(ID3D11DeviceContext* context) = 0;
};
