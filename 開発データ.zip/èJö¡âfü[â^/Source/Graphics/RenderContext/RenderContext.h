#pragma once

#include <DirectXMath.h>

// �����_�[�R���e�L�X�g
class RenderContext
{
public:
	DirectX::XMFLOAT4X4		view;
	DirectX::XMFLOAT4X4		projection;
	DirectX::XMFLOAT4		lightDirection;

//public:
//	//�Z�b�^�[
//	void SetView(DirectX::XMFLOAT4X4 view) { this->view = view; };
//	void SetProjection(DirectX::XMFLOAT4X4 projection) { this->projection = projection; };
//	void SetLightDirection(DirectX::XMFLOAT4 lightDirection) { this->lightDirection = lightDirection; };
//
//	//�Q�b�^�[
//	const DirectX::XMFLOAT4X4& GetView() const { return view; };
//	const DirectX::XMFLOAT4X4& GetProjection() const { return projection; };
//	const DirectX::XMFLOAT4& const GetLightDirection() { return lightDirection; };
};
