#include <wrl.h>
#include "Game/Misc/Misc.h"
#include "Trajectory.h"
#include "Graphics/Graphics.h"
#include <WICTextureLoader.h>

Trajectory::Trajectory(int exist_max, DirectX::XMFLOAT3* head_position, DirectX::XMFLOAT3* tail_position, bool* is_used)
{
	//���̈ʒu������
    temp_position.head_position = head_position;
    temp_position.tail_position = tail_position;
    temp_position.is_used = is_used;
    temp_position.exist_timer = exist_max;
	this->exist_max = exist_max;
}

void Trajectory::Update(bool split_flag)
{
	used_array.clear();//�R���e�i������
    //���̈ʒu��ۑ�
	PositionBuffer test_position = { *temp_position.head_position, *temp_position.tail_position, *temp_position.is_used, temp_position.exist_timer, 0 };
	position_array.insert(position_array.begin(), test_position);//�擪�ɗv�f�ǉ�

	for (int i = 0; i < position_array.size(); i++)
	{
		position_array.operator[](i).iterator = i;//�C�e���[�^�[���

		//�ŐV�̌�����is_used��false
		if (!position_array.operator[](0).is_used && i < position_array.size() - 1)
		{
			//���̏�����O�̗v�f�Ɉړ�
			position_array.operator[](i).head_position = position_array.operator[](i + 1).head_position; //���̐�[�̈ʒu
			position_array.operator[](i).tail_position = position_array.operator[](i + 1).tail_position; //���̍��{�̈ʒu
			position_array.operator[](i).is_used = position_array.operator[](i + 1).is_used;//�g�p����Ă��邩�ǂ���
			position_array.operator[](i).exist_timer = position_array.operator[](i + 1).exist_timer;//��������
			position_array.operator[](i).iterator = position_array.operator[](i + 1).iterator;//�R���e�i�̃C�e���[�^
		}

		//�g�p�t���O��true�������ꍇ
		if (position_array.operator[](i).is_used)
		{
			//�g�p������R���e�i�Ɍ��̏����i�[
			used_array.emplace_back(position_array.operator[](i));//�����ɗv�f�ǉ�
		}
		//�������ԍX�V
		position_array.operator[](i).exist_timer--;//�������ԍX�V
		if (position_array.operator[](i).exist_timer <= 0)//�������Ԃ��؂�Ă�����
		{
			position_array.erase(position_array.begin() + i);//�������Ԃ̐؂ꂽ���̗v�f���폜
		}
	}
	if (split_flag)CreateCurveVertex(used_array);//�O�Ղ̕⊮
}

void Trajectory::CreateCurveVertex(std::vector<PositionBuffer>& used_position_array)
{
    if (used_position_array.size() < 3 || split < 1) { return; }
    std::vector<PositionBuffer> newPosArray;
    newPosArray.reserve(used_position_array.size() + (used_position_array.size() - 1) * split);
    const float amount = 1.0f / (split + 1);

    PositionBuffer newPos;
    newPosArray.push_back(used_position_array.front());
    for (size_t i = 0; i < used_position_array.size() - 1; ++i)
    {
        float ratio = amount;
        //  CatMul�Ɏg��4�̓_�����ip0, p3���Ȃ����̏����������j
        DirectX::XMVECTOR p0Head = i == 0 ? DirectX::XMVectorScale((DirectX::XMVectorAdd(XMLoadFloat3(&used_position_array[1].head_position) , XMLoadFloat3(&used_position_array[2].head_position))) , 0.5f) : XMLoadFloat3(&used_position_array[i - 1].head_position);
        DirectX::XMVECTOR p1Head = XMLoadFloat3(&used_position_array[i].head_position);
        DirectX::XMVECTOR p2Head = XMLoadFloat3(&used_position_array[i + 1].head_position);
		DirectX::XMVECTOR p3Head = i == used_position_array.size() - 2 ? DirectX::XMVectorScale(DirectX::XMVectorAdd(p0Head, p2Head), 0.5f) : XMLoadFloat3(&used_position_array[i + 2].head_position);

        DirectX::XMVECTOR p0Tail = i == 0 ? DirectX::XMVectorScale((DirectX::XMVectorAdd(XMLoadFloat3(&used_position_array[1].tail_position) , XMLoadFloat3(&used_position_array[2].tail_position))) , 0.5f): XMLoadFloat3(&used_position_array[i - 1].tail_position);
        DirectX::XMVECTOR p1Tail = XMLoadFloat3(&used_position_array[i].tail_position);
        DirectX::XMVECTOR p2Tail = XMLoadFloat3(&used_position_array[i + 1].tail_position);
        DirectX::XMVECTOR p3Tail = i == used_position_array.size() - 2 ? DirectX::XMVectorScale(DirectX::XMVectorAdd(p0Tail , p2Tail) , 0.5f) : XMLoadFloat3(&used_position_array[i + 2].tail_position);

        for (size_t j = 0; j < static_cast<size_t>(split - 1); ++j)
        {
            newPos = PositionBuffer();

            newPos.is_used = true;
            DirectX::XMStoreFloat3(&newPos.head_position, DirectX::XMVectorCatmullRom(p0Head, p1Head, p2Head, p3Head, ratio));
            DirectX::XMStoreFloat3(&newPos.tail_position, DirectX::XMVectorCatmullRom(p0Tail, p1Tail, p2Tail, p3Tail, ratio));

            newPosArray.push_back(newPos);
            ratio += amount;
        }
        newPosArray.push_back(used_position_array[i + 1]);
    }
    used_position_array = newPosArray;
}
