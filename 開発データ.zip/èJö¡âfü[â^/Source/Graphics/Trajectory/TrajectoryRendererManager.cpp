#include "TrajectoryRendererManager.h"
#include "Game/Character/Player/PlayerManager.h"

void TrailRendererManager::Update()
{
	for (TrailRenderer* renderer : renderers)
	{
		renderer->Update();
	}
}

void TrailRendererManager::Render(ID3D11DeviceContext* dc, const RenderContext& rc)
{
	for (TrailRenderer* renderer : renderers)
	{
		renderer->Render(dc, rc, 1.0f, 1.0f, 1.0f, .0f);
	}
}

void TrailRendererManager::Clear()
{
	for (TrailRenderer* renderer : renderers)
	{
		delete renderer;
	}
	renderers.clear();
}

void TrailRendererManager::SetTrailRenderer(int exist_max, const wchar_t* filename, DirectX::XMFLOAT3* head_position, DirectX::XMFLOAT3* tail_position, bool* used_flag, bool split_flag)
{
	trail_renderer = std::make_unique<TrailRenderer>(exist_max, filename, head_position, tail_position, used_flag, split_flag);
	trail_renderer->Initialize();
	renderers.emplace_back(std::move(trail_renderer.get()));
	trail_renderer.release();
}