#pragma once
#include "Graphics/Graphics.h"
#include <memory>
#include <wrl.h>
#include <cstdint>
#include "Graphics/Texture/Texture.h"
#include "Trajectory.h"


class TrailRenderer
{
private:
	std::unique_ptr<Trajectory> trajectory = nullptr;

public:
	TrailRenderer(int exist_max, const wchar_t* filename, DirectX::XMFLOAT3* head_position, DirectX::XMFLOAT3* tail_position, bool* is_used, bool split_flag);	
	~TrailRenderer() {};
	void Initialize();  //������
	void Update();//�����t���O�ǉ�

    void Render(ID3D11DeviceContext* immediate_context, const RenderContext& rc, float r, float g, float b, float a); //�`��

	//�C���X�^���X�쐬
	void CreateInstance(int exist_max, DirectX::XMFLOAT3* head_position, DirectX::XMFLOAT3* tail_position, bool* is_used)
	{
		if (trajectory) return;

		trajectory = std::make_unique<Trajectory>(exist_max, head_position, tail_position, is_used);
	}

	//�C���X�^���X�폜�����֐�
	void DestroyInstance()
	{
		if (!trajectory)return;

		trajectory.reset();
	}

	Trajectory* GetInstance() { return trajectory.get(); }

private:
	//���_�o�b�t�@
	struct SwordTrailVertex
	{
		DirectX::XMFLOAT3 position = { 0, 0, 0 };
		DirectX::XMFLOAT4 color = { .0f, .0f, .0f, .0f };
		DirectX::XMFLOAT2 uv = { 0, 0 };
		int exist_timer;//�ǉ� ��������
	};

	//�萔�o�b�t�@
	struct ConstantBuffer
	{
		DirectX::XMFLOAT4X4	viewProjection;
	};

private:
    bool is_initialized = false;//����������Ă��邩

	static const int VERTEX_MIN = 4;//�ŏ����_��
	int vertex_max;//�ő咸�_��

	std::vector<SwordTrailVertex> vertices;//���_�o�b�t�@
	std::vector<u_int> indices;//�C���f�b�N�X�o�b�t�@

private:
	Microsoft::WRL::ComPtr<ID3D11VertexShader>			vertexShader;
	Microsoft::WRL::ComPtr<ID3D11PixelShader>			pixelShader;
	Microsoft::WRL::ComPtr<ID3D11InputLayout>			inputLayout;

	Microsoft::WRL::ComPtr<ID3D11Buffer>				vertexBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer>				indexBuffer;

	Microsoft::WRL::ComPtr<ID3D11Buffer>			    constantBuffer;

	Microsoft::WRL::ComPtr<ID3D11BlendState>			blendState;
	Microsoft::WRL::ComPtr<ID3D11RasterizerState>		rasterizerState;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilState>		depthStencilState;

	Microsoft::WRL::ComPtr<ID3D11SamplerState>			samplerState;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>	shaderResourceView;

	std::shared_ptr<Texture> texture;
private:
	int m_IndexCount;       //�C���f�b�N�X��
	int vertex_size;//���_�o�b�t�@�̑傫��
	int index_size;

private:
	bool split_flag = false;
};