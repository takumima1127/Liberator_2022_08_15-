#include "ExpansionFont.h"

ExpansionFont::ExpansionFont(float x, float y, float scale, float scale_factor, float exist_timer, const wchar_t* string, DirectX::XMFLOAT4 color, int type, int id)
{
	position = DirectX::XMFLOAT2(x, y);
	this->scale = scale;
	this->scale_factor = scale_factor;
	this->exist_timer = exist_timer;
	//this->string = std::make_unique<const wchar_t>(string);
	this->string = string;
	this->color = color;
	this->type = type;
	this->id = id;
}

void ExpansionFont::Update(float elapsed_time)
{
	scale += scale_factor;//�����g�嗦�X�V
	if (exist_timer < 1.0f)
	{
		color.w -= elapsed_time;
	}
	exist_timer -= elapsed_time;//�������ԍX�V
}

void ExpansionFont::Render(ID3D11DeviceContext* dc, Font* font)
{
	//�t�H���g�`��
	//font->Draw(position.x, position.y, scale, string.get());
	font->Draw(position.x, position.y, scale, string, color, true);
}
