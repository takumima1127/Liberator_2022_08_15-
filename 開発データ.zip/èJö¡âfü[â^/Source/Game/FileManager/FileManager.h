#pragma once
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include "Game/Data/AttackData/Player/PlayerAttackData.h"
#include "Game/EventSystem/Mission/EnemyData/EnemyData.h"
#include "Game/EventSystem/Mission/MissionData/MissionData.h"
#include "Singleton/Singleton.h"

class FileManager : public Singleton<FileManager>
{
public:
	FileManager() {};
	~FileManager() {};

	std::vector<EnemyData::SetData> LoadFileEnemyData(const char* file_name);//�G�z�u�f�[�^�̓ǂݍ���
	std::vector<MissionData::SetData> LoadFileMissionData(const char* file_name);//�~�b�V�����f�[�^�̓ǂݍ���

private:
	std::vector<std::string> split(std::string& input, char delimiter);//csv�f�[�^�p�A��؂镶���w��
};