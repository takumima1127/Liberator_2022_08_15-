#include "PlayerManager.h"

void PlayerManager::Initialize()
{
	GetPlayerInstance()->Initialize();
}

void PlayerManager::Update(float elapsed_time)
{
	GetPlayerInstance()->Update(elapsed_time);
}

void PlayerManager::Render(ID3D11DeviceContext* dc, Shader* shader)
{
	GetPlayerInstance()->Render(dc, shader);
}

void PlayerManager::DrawDebugPrimitive()
{
	GetPlayerInstance()->DrawDebugPrimitive();
}

void PlayerManager::AttackDataSet()
{
	attack_data_array.resize(static_cast<int>(Player::AttackState::MAX));
	//�ʏ�U���i��i�ځj
	attack_data_array[static_cast<int>(Player::AttackState::Attack01)].SetCancelTime(0.6f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack01)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack01)].SetBeginTrajectoryTime(0.37f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack01)].SetEndTrajectoryTime(0.6f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack01)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 50, 0.45f, 0.60f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::Attack01)].SetHitMax();

	//�ʏ�U���i��i�ځj
	attack_data_array[static_cast<int>(Player::AttackState::Attack02)].SetCancelTime(0.6f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack02)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack02)].SetBeginTrajectoryTime(0.24f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack02)].SetEndTrajectoryTime(0.4f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack02)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 50, 0.28f, 0.4f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::Attack02)].SetHitMax();


	//�ʏ�U���i�O�i�ځj
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetCancelTime(1.2f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetBeginTrajectoryTime(0.05f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetEndTrajectoryTime(0.46f);
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 30, 0.08f, 0.18f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 30, 0.19f, 0.3f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 90, 0.42f, 0.47f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::Attack03)].SetHitMax();

	//�X�e�b�v�U��
	attack_data_array[static_cast<int>(Player::AttackState::StepAttack)].SetCancelTime(0.5f);
	attack_data_array[static_cast<int>(Player::AttackState::StepAttack)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::StepAttack)].SetBeginTrajectoryTime(-1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::StepAttack)].SetEndTrajectoryTime(-1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::StepAttack)].SetCollisionData("left_toe", HASH_DIGEST("left_toe"), 50, 0.45f, 0.60f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::StepAttack)].SetHitMax();

	//�_�b�V���U��
	attack_data_array[static_cast<int>(Player::AttackState::DashAttack)].SetCancelTime(0.6f);
	attack_data_array[static_cast<int>(Player::AttackState::DashAttack)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::DashAttack)].SetBeginTrajectoryTime(0.1f);
	attack_data_array[static_cast<int>(Player::AttackState::DashAttack)].SetEndTrajectoryTime(0.33f);
	attack_data_array[static_cast<int>(Player::AttackState::DashAttack)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 60, 0.26f, 0.3f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::DashAttack)].SetHitMax();

	//�J�E���^�[�U��
	attack_data_array[static_cast<int>(Player::AttackState::CounterAttack)].SetCancelTime(0.5f);
	attack_data_array[static_cast<int>(Player::AttackState::CounterAttack)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::CounterAttack)].SetBeginTrajectoryTime(0.12f);
	attack_data_array[static_cast<int>(Player::AttackState::CounterAttack)].SetEndTrajectoryTime(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::CounterAttack)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 80, 0.12f, 0.18f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::CounterAttack)].SetHitMax();

	//���ߍU��
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetCancelTime(0.5f);
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetPower(1.0f);
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetBeginTrajectoryTime(0.15f);
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetEndTrajectoryTime(0.7f);
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 40, 0.05f, 0.2f);//1it��
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 40, 0.21f, 0.34f);//2it��
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetCollisionData("weapon", HASH_DIGEST("weapon"), 90, 0.35f, 0.55f);//3it��
	attack_data_array[static_cast<int>(Player::AttackState::AccumulateAttack)].SetHitMax();
};
