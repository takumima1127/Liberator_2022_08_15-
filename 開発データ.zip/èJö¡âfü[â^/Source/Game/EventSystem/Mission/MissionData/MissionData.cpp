#include "Game/EventSystem/Mission/MissionData/MissionData.h"
#include "Game/FileManager/FileManager.h"

MissionData::MissionData()
{
	FileManager& file_manager = FileManager::GetInstance();
	file_data_array.clear();
	file_data_array = file_manager.LoadFileMissionData("Data/Mission/MissionData/data_01.csv");

	//�G�f�[�^�o�^
	data_array.insert(std::make_pair(MissionData::FileState::Data_01, file_data_array.at(static_cast<int>(Mission::MissionState::Mission1))));
	data_array.insert(std::make_pair(MissionData::FileState::Data_02, file_data_array.at(static_cast<int>(Mission::MissionState::Mission2))));
	data_array.insert(std::make_pair(MissionData::FileState::Data_03, file_data_array.at(static_cast<int>(Mission::MissionState::Mission3))));
}

MissionData::SetData MissionData::GetData(int state)
{
	MissionData::FileState file_state = static_cast<MissionData::FileState>(state);
	
	return data_array.at(file_state);
}
