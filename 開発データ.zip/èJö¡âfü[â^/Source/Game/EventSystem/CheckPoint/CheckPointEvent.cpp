#include "CheckPointEvent.h"
#include "CheckPointEventManager.h"

CheckPointEvent::CheckPointEvent(DirectX::XMFLOAT3 position, float scale, float height, DirectX::XMFLOAT3 camera_angle)
{
	this->position = position;
	this->scale = scale;
	this->height = height;
	this->camera_angle = camera_angle;
	is_finishd = false;

	//�R���C�_�[�̐ݒ�
	//cylinder_collider_ptr = std::make_shared<CylinderCollider>("area", &position, scale, height, 0, true);
}

void CheckPointEvent::Destroy()
{
	CheckPointEventManager::GetInstance().Remove(this);
}

void CheckPointEvent::Initialize()
{
}

void CheckPointEvent::Update(float elapsed_time)
{
}

void CheckPointEvent::DrawDebugPrimitive()
{
	//Event::DrawDebugPrimitive();
	DebugRenderer* debugRenderer = Graphics::Instance().GetDebugRenderer();
	debugRenderer->DrawCylinder(position, scale, height, DirectX::XMFLOAT4(0.0f, 0.0f, 0.0f, 1.0f));
}
