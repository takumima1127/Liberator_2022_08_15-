#pragma once

#include "Graphics/Model/Model.h"
#include "Game/Projectile/Projectile.h"

//���i�e
class ProjectileStraight : public Projectile
{
public:
	ProjectileStraight(ProjectileManager* manager);
	~ProjectileStraight() override;

	//�X�V����
	void Update(float elapsed_time) override;

	//�`�揈��
	void Render(ID3D11DeviceContext* dc, Shader* shader) override;

	//����
	void Launch(const DirectX::XMFLOAT3& direction, const DirectX::XMFLOAT3& position);

private:
	Model* model = nullptr;
	float speed = 10.0f;
	float life_timer = 60.0f;
};