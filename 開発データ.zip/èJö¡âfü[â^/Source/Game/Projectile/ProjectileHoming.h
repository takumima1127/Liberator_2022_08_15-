#pragma once

#include "Graphics/Model/Model.h"
#include "Game/Projectile/Projectile.h"

//�ǔ��e��
class ProjectileHoming : public Projectile
{
public:
	ProjectileHoming(ProjectileManager* manager);
	~ProjectileHoming() override;

	//�X�V����
	void Update(float elapsed_time) override;

	//�`�揈��
	void Render(ID3D11DeviceContext* dc, Shader* shader) override;

	//����
	void Launch(const DirectX::XMFLOAT3& direction,
	            const DirectX::XMFLOAT3& position,
		        const DirectX::XMFLOAT3& target);

private:
	Model* model = nullptr;
	DirectX::XMFLOAT3 target = { 0, 0, 0 };
	float move_speed = 10.0f;
	float turn_speed = DirectX::XMConvertToRadians(180);
	float life_timer = 10.0f;
};