#pragma once
#include <memory>
#include <vector>
#include "Graphics/Graphics.h"
#include "Game/UI/Damage/DamageData/DamageData.h"
#include "Singleton/Singleton.h"

class DamageRenderer : public Singleton<DamageRenderer>
{
private:
    inline static std::unique_ptr<DamageRenderer> instance = nullptr;

public:
    DamageRenderer();
    ~DamageRenderer();

    //�Z�b�g
    void Set(int damage, DirectX::XMFLOAT3 position, int exist_timer = EXIST_TIMER_MAX);

    //�X�V����
    void Update(float elapsed_time);

    //�`�揈��
    void Render(ID3D11DeviceContext* dc, Font* font, const DirectX::XMFLOAT4X4& view, const DirectX::XMFLOAT4X4& projection);
    
    //�폜
    void Remove(DamageData* damage_data);
    
    //�S�폜
    void Clear();

private:
    //�萔
    static const  int EXIST_TIMER_MAX = 100;

private:
    std::vector<DamageData*> data;//TODO array�ɖ����ύX
    std::vector<DamageData*> removes;
    std::unique_ptr<DamageData> damage_data;
};