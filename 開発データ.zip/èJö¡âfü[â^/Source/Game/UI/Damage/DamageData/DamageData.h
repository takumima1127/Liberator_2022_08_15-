#pragma once
#include "Graphics/Graphics.h"
#include "Graphics/Font/Font.h"

class DamageData
{
public:
    DamageData() {};
    ~DamageData() {};
    
    // ������
    void Initialize(int damage, DirectX::XMFLOAT3 position, int exist_timer, int id);

    //�X�V����
    void Update(float elapsed_time);

    //�`��
    void Render(ID3D11DeviceContext* dc, Font* font, const DirectX::XMFLOAT4X4& view, const DirectX::XMFLOAT4X4& projection);

public:
    //�������Ԏ擾
    const int& GetId() const { return id; }
    const int& GetExistTimer() const { return exist_timer; }

private:
    //�萔
    const float FONT_SIZE = 1.0f;

private:
    int damage = -1;//�_���[�W
    int id = -1;//�z��ԍ�
    int exist_timer = 0;
    DirectX::XMFLOAT3 position = DirectX::XMFLOAT3(.0f, .0f, .0f);
    DirectX::XMFLOAT2 offset = DirectX::XMFLOAT2(.0f, .0f);
};