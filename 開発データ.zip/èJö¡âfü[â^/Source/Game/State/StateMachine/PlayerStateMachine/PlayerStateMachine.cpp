#include "PlayerStateMachine.h"

void PlayerStateMachine::StateInit(Model* model, uint32_t next_state_hash, uint32_t next_animation_hash, uint32_t next_attack_state_hash)
{
	current_state = GetStateArray()[next_state_hash];
	this->transition_state_hash = HASH_DIGEST("Idle");
	attack_state_hash = next_attack_state_hash;

#if 1
	if (current_state.GetBlendSeconds() == .0f)model->PlayAnimation(GetAnimationArray()[next_animation_hash], current_state.GetIsLoop());
	else model->PlayAnimation(GetAnimationArray()[next_animation_hash], current_state.GetIsLoop(), current_state.GetBlendSeconds());
#else
	model->PlayAnimation(GetAnimationArray()[next_state_hash], current_state.GetIsLoop(), current_state.GetBlendSeconds());
#endif
	
	if (current_state.GetBeginAnimationTime() != .0f)	model->SetCurrentAnimationSeconds(current_state.GetBeginAnimationTime());

	//�K�[�h�t���O������
	GuardInit();

	//�O�Ղ̐����t���O
	trajectory_sword_flag = false;
	trajectory_toe_flag = false;
}

void PlayerStateMachine::AttackTrajectory(float animation_time)
{
	//int num = attack_state_array[attack_state_hash];
	//attack_data_array[attack_state_array[attack_state_hash]].GetHitMax();

	{
		for (int i = 0; i < attack_data_array[attack_state_array[attack_state_hash]].GetHitMax(); i++)
		{
			//�O�Ղ̐���
			if (animation_time >= attack_data_array[attack_state_array[attack_state_hash]].GetBeginTrajectoryTime()
				&& animation_time <= attack_data_array[attack_state_array[attack_state_hash]].GetEndTrajectoryTime())
			{
				//�O�Ղ𐶐�
				trajectory_sword_flag = true;
			}
			else
			{
				//�O�Ղ𐶐����Ȃ�
				trajectory_sword_flag = false;
			}
		}
	}
}

void PlayerStateMachine::GuardInit()
{
	//�K�[�h�t���O������
	SetGuardFlag(GuardState::GuardNone);
	//�J�E���^�[�t���O������
	SetCounterFlag(CounterState::CounterNone);
}

void PlayerStateMachine::AttackDataInit()
{
	attack_hit_count = 0;//�q�b�g��������
	for (int i = 0; i < attack_data_array.size(); i++)
	{
		for (int j = 0; j < attack_data_array[i].GetHitMax(); j++)
		{
			//����t���O������
			attack_data_array[i].SetCollisionFlag(j, PlayerAttackData::AttackCollisionFlag::Before);
		}
	}
}
