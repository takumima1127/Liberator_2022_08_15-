#include "EnemyStateMachine.h"

void EnemyStateMachine::StateInit(Model* model, uint32_t next_state_hash, uint32_t next_animation_hash, uint32_t next_attack_state_hash)
{
	current_state = GetStateArray()[next_state_hash];
	this->transition_state_hash = HASH_DIGEST("Idle");
	attack_state_hash = next_attack_state_hash;

	if (current_state.GetBlendSeconds() == .0f)model->PlayAnimation(GetAnimationArray()[next_animation_hash], current_state.GetIsLoop());
	else model->PlayAnimation(GetAnimationArray()[next_animation_hash], current_state.GetIsLoop(), current_state.GetBlendSeconds());

	if (current_state.GetBeginAnimationTime() != .0f)	model->SetCurrentAnimationSeconds(current_state.GetBeginAnimationTime());
}

void EnemyStateMachine::AttackDataInit()
{
	attack_hit_count = 0;//�q�b�g��������
	for (int i = 0; i < attack_data_array.size(); i++)
	{
		for (int j = 0; j < attack_data_array[i].GetHitMax(); j++)
		{
			//����t���O������
			attack_data_array[i].SetCollisionFlag(j, EnemyAttackData::AttackCollisionFlag::Before);
		}
	}
}
