#include "State.h"

State::State()
{
	this->name_hash = 0;
	this->gravity_flag = false;
	this->animation_index = -1;
	this->is_loop = false;
	this->begin_animation_time = .0f;
	this->blend_seconds = .0f;
}

State::State(uint32_t name_hash, bool gravity_flag, int animation_index, bool is_loop, float begin_animation_time, float blend_seconds)
{
	this->name_hash = name_hash;
	this->gravity_flag = gravity_flag;
	this->animation_index = animation_index;
	this->is_loop = is_loop;
	this->begin_animation_time = begin_animation_time;
	this->blend_seconds = blend_seconds;
}