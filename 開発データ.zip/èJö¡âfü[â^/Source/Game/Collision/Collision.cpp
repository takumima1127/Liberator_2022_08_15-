#include "Collision.h"
#include <cassert>
#include <algorithm>
#include <functional>
#include "Math/Vector/Vector.h"

#include <functional>
#include <iostream>


//TODO using namespace ������
using namespace DirectX;

void Collision::Initialize()
{
}

DirectX::XMVECTOR Collision::ClosestPointOnLineSegment(DirectX::XMVECTOR A, DirectX::XMVECTOR B, DirectX::XMVECTOR Point)
{
	DirectX::XMVECTOR AB = DirectX::XMVectorSubtract(B, A);
	DirectX::XMVECTOR Left = DirectX::XMVector3Dot(DirectX::XMVectorSubtract(Point, A), AB);
	DirectX::XMVECTOR Right = DirectX::XMVector3Dot(AB, AB);
	
	float left, right;
	DirectX::XMStoreFloat(&left, Left);
	DirectX::XMStoreFloat(&right, Right);

	float t = left / right;
	//float t = DirectX::XMVector3Dot(DirectX::XMVectorSubtract(Point, A), AB) / DirectX::XMVector3Dot(AB, AB);
	return A + std::fminf(std::fmaxf(t, 0), 1.0f) * AB;
}

bool Collision::IntersectPointVsCircle(DirectX::XMFLOAT3 positionA, DirectX::XMFLOAT3 positionB, float radiusB)
{
	DirectX::XMFLOAT2 posision_a = DirectX::XMFLOAT2(positionA.x, positionA.z);
	DirectX::XMFLOAT2 posision_b = DirectX::XMFLOAT2(positionB.x, positionB.z);

	//B->A�̒P�ʃx�N�g�����Z�o
	DirectX::XMVECTOR PositionA = XMLoadFloat2(&posision_a);
	DirectX::XMVECTOR PositionB = XMLoadFloat2(&posision_b);
	DirectX::XMVECTOR Vec = DirectX::XMVectorSubtract(PositionB, PositionA);
	DirectX::XMVECTOR LengthSq = DirectX::XMVector2LengthSq(Vec);
	float lengthSq;
	DirectX::XMStoreFloat(&lengthSq, LengthSq);
	//XZ���ʂł͈̔̓`�F�b�N

//��������
	float VX = positionB.x - positionA.x;
	float VZ = positionB.z - positionA.z;
	float range = radiusB;
	float DistXZ = sqrtf((VX * VX) + (VZ * VZ));
	if (DistXZ > range)
	{
		return false;
	}
	return true;
}

//���Ƌ��̌�������
bool Collision::IntersectSphereVsSphere(const DirectX::XMFLOAT3& positionA, float radiusA, const DirectX::XMFLOAT3& positionB, float radiusB, DirectX::XMFLOAT3& outPositionB)
{
	//B->A�̒P�ʃx�N�g�����Z�o
	DirectX::XMVECTOR PositionA = XMLoadFloat3(&positionA);
	DirectX::XMVECTOR PositionB = XMLoadFloat3(&positionB);
	DirectX::XMVECTOR Vec       = DirectX::XMVectorSubtract(PositionB, PositionA);
	DirectX::XMVECTOR LengthSq  = DirectX::XMVector3LengthSq(Vec);
	float lengthSq;
	DirectX::XMStoreFloat(&lengthSq, LengthSq);
	
	//��������
	float range = radiusA + radiusB;
	if (lengthSq > range)
	{
		return false;
	}
	
	//A��B�������o��
	Vec = DirectX::XMVector3Normalize(Vec);
	Vec = DirectX::XMVectorScale(Vec, range);
	PositionB = DirectX::XMVectorAdd(PositionA, Vec);
	DirectX::XMStoreFloat3(&outPositionB, PositionB);
	return true;
}

bool Collision::IntersectCylinderVsCylinder(const DirectX::XMFLOAT3& positionA, float radiusA, float heightA, const DirectX::XMFLOAT3& positionB, float radiusB, float heightB, DirectX::XMFLOAT3& outPositionB)
{
	//A�̑�����B�̓�����Ȃ瓖�����Ă��Ȃ�
	if (positionA.y > positionB.y + heightB)
	{
		return false;
	}

	//A�̓���B�̑�����艺�Ȃ瓖�����Ă��Ȃ�
	if (positionA.y + heightA < positionB.y)
	{
		return false;
	}

	//XZ���ʂł͈̔̓`�F�b�N
	
	//��������
	float VX = positionB.x - positionA.x;
	float VZ = positionB.z - positionA.z;
	float range = radiusA + radiusB;
	float DistXZ = sqrtf((VX * VX) + (VZ * VZ));
	if (DistXZ > range)
	{
		return false;
	}

	//A��B�������o��
	VX /= DistXZ;
	VZ /= DistXZ;
	outPositionB.x = positionA.x + VX * range;
	outPositionB.y = positionB.y;
	outPositionB.z = positionA.z + VZ * range;

	return true;
}

//���Ɖ~���̌�������
bool Collision::IntersectSphereVsCylinder(const DirectX::XMFLOAT3& spherePosition, float sphereRadius, const DirectX::XMFLOAT3& cylinderPosition, float cylinderRadius, float cylinderHeight)
{
	//�����`�F�b�N
	if (spherePosition.y + sphereRadius < cylinderPosition.y) return false;
	if (spherePosition.y - sphereRadius > cylinderPosition.y + cylinderHeight) return false;

	//XZ���ʂł͈̔̓`�F�b�N
	float VX = cylinderPosition.x - spherePosition.x;
	float VZ = cylinderPosition.z - spherePosition.z;

	float range = sphereRadius + cylinderRadius;
	float DistXZ = sqrtf((VX * VX) + (VZ * VZ));
	if (DistXZ > range)
	{
		return false;
	}

	return true;
}

bool Collision::IntersectSphereVsCapsule(const DirectX::XMFLOAT3& spherePosition, float sphereRadius, const DirectX::XMFLOAT3& CapsulePosition1, const DirectX::XMFLOAT3& CapsulePosition2, float CapsuleRadius, DirectX::XMFLOAT3& hit_position)
{
	//capsule
	DirectX::XMVECTOR c_Position1 = XMLoadFloat3(&CapsulePosition1);
	DirectX::XMVECTOR c_Position2 = XMLoadFloat3(&CapsulePosition2);
	DirectX::XMVECTOR c_Normal = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(c_Position2, c_Position1));
	DirectX::XMVECTOR c_LineEndOffset = c_Normal * CapsuleRadius;
	DirectX::XMVECTOR a_A = c_Position1 + c_LineEndOffset;
	DirectX::XMVECTOR a_B = c_Position2 - c_LineEndOffset;

	////sphere
	DirectX::XMVECTOR s_Position = XMLoadFloat3(&spherePosition);

	float radius_length = CapsuleRadius + sphereRadius;

	float d0;
	DirectX::XMStoreFloat(&d0, DirectX::XMVector3Dot(c_Normal, DirectX::XMVectorSubtract(s_Position, c_Position1)));
	
	DirectX::XMVECTOR pn = c_Position1 + DirectX::XMVectorScale(c_Normal, d0);

	float length_1;
	DirectX::XMStoreFloat(&length_1,DirectX::XMVector3Length(DirectX::XMVectorSubtract(pn, c_Position1)));
	float length_2;
	DirectX::XMStoreFloat(&length_2, DirectX::XMVector3Length(DirectX::XMVectorSubtract(c_Position2, c_Position1)));
	
	length_1 /= length_2;

	float dist_0;
	DirectX::XMStoreFloat(&dist_0, DirectX::XMVector3Length(s_Position - pn));

	//float dist_1;
	//DirectX::XMStoreFloat(&dist_0, DirectX::XMVector3Length(s_Position - c_Position2));
	//
	//float dist_2;
	//DirectX::XMStoreFloat(&dist_0, DirectX::XMVector3Length(s_Position - c_Position1));

	float length_3;
	DirectX::XMStoreFloat(&length_3, DirectX::XMVector3Length(DirectX::XMVectorSubtract(s_Position, pn)));

	float length_4;
	DirectX::XMStoreFloat(&length_4, DirectX::XMVector3Length(DirectX::XMVectorSubtract(s_Position, c_Position2)));

	float length_5;
	DirectX::XMStoreFloat(&length_5, DirectX::XMVector3Length(DirectX::XMVectorSubtract(s_Position, c_Position1)));


	if (length_1 < 1.0f && length_1 > 0.0f)
	{
		if (length_3 - radius_length < 0)
		{
			return true;
		}
	}
	else if (length_1 > 1.0f)
	{
		if (length_4 - radius_length < 0)
		{
			return true;
		}
	}
	else  if (length_1 < 0.0f)
	{
		if (length_5 - radius_length < 0)
		{
			return true;
		}
	}
	return false;
}

bool Collision::IntersectCapsuleVsCapsule(const DirectX::XMFLOAT3& CapsuleAPosition1, const DirectX::XMFLOAT3& CapsuleAPosition2, float CapsuleARadius, const DirectX::XMFLOAT3& CapsuleBPosition1, const DirectX::XMFLOAT3& CapsuleBPosition2, float CapsuleBRadius)
{
	//capsule0
	DirectX::XMVECTOR cA_Position1 = XMLoadFloat3(&CapsuleAPosition1);
	DirectX::XMVECTOR cA_Position2 = XMLoadFloat3(&CapsuleAPosition2);
	DirectX::XMVECTOR cA_Normal = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(cA_Position2, cA_Position1));
	DirectX::XMVECTOR cA_LineEndOffset = cA_Normal * CapsuleARadius;
	DirectX::XMVECTOR a_A = cA_Position1 + cA_LineEndOffset;
	DirectX::XMVECTOR a_B = cA_Position2 - cA_LineEndOffset;

	//capsule1
	DirectX::XMVECTOR cB_Position1 = XMLoadFloat3(&CapsuleBPosition1);
	DirectX::XMVECTOR cB_Position2 = XMLoadFloat3(&CapsuleBPosition2);
	DirectX::XMVECTOR cB_Normal = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(cB_Position2, cB_Position1));
	DirectX::XMVECTOR cB_LineEndOffset = cB_Normal * CapsuleBRadius;
	DirectX::XMVECTOR b_A = cB_Position1 + cB_LineEndOffset;
	DirectX::XMVECTOR b_B = cB_Position2 - cB_LineEndOffset;

	// vectors between line endpoints:
	DirectX::XMVECTOR v0 = b_A - a_A;
	DirectX::XMVECTOR v1 = b_B - a_A;
	DirectX::XMVECTOR v2 = b_A - a_B;
	DirectX::XMVECTOR v3 = b_B - a_B;

	// squared distances:
	float d0;
	DirectX::XMStoreFloat(&d0 ,DirectX::XMVector3Dot(v0, v0));
	float d1;
	DirectX::XMStoreFloat(&d1, DirectX::XMVector3Dot(v1, v1));
	float d2;
	DirectX::XMStoreFloat(&d2, DirectX::XMVector3Dot(v2, v2));
	float d3;
	DirectX::XMStoreFloat(&d3, DirectX::XMVector3Dot(v3, v3));

	// select best potential endpoint on capsule A:
	DirectX::XMVECTOR bestA;
	if (d2 < d0 || d2 < d1 || d3 < d0 || d3 < d1)
	{
		bestA = a_B;
	}
	else
	{
		bestA = a_A;
	}

	// select point on capsule B line segment nearest to best potential endpoint on A capsule:
	DirectX::XMVECTOR bestB = ClosestPointOnLineSegment(b_A, b_B, bestA);

	// now do the same for capsule A segment:
	bestA = ClosestPointOnLineSegment(a_A, a_B, bestB);

	DirectX::XMVECTOR penetration_normal = bestA - bestB;
	float len;
	DirectX::XMStoreFloat(&len ,DirectX::XMVector3Length(penetration_normal));

	penetration_normal /= len;  // normalize
	float penetration_depth = CapsuleARadius + CapsuleBRadius - len;
	//bool intersects = penetration_depth > 0;
	if (penetration_depth > 0)
	{
		//�������Ă���
		return true;
	}
	else
	{
		//�������Ă��Ȃ�
		return false;
	}
}

bool Collision::IntersectCapsuleVsCapsule2(const DirectX::XMFLOAT3& CapsuleAPosition1, const DirectX::XMFLOAT3& CapsuleAPosition2, float CapsuleARadius, const DirectX::XMFLOAT3& CapsuleBPosition1, const DirectX::XMFLOAT3& CapsuleBPosition2, float CapsuleBRadius, DirectX::XMFLOAT3& hit_position)
{
	//capsule0
	DirectX::XMVECTOR cA_Position1 = XMLoadFloat3(&CapsuleAPosition1);
	DirectX::XMVECTOR cA_Position2 = XMLoadFloat3(&CapsuleAPosition2);
	DirectX::XMVECTOR cA_Normal = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(cA_Position2, cA_Position1));
	DirectX::XMVECTOR cA_LineEndOffset = cA_Normal * CapsuleARadius;
	DirectX::XMVECTOR a_A = cA_Position1 + cA_LineEndOffset;
	DirectX::XMVECTOR a_B = cA_Position2 - cA_LineEndOffset;

	//capsule1
	DirectX::XMVECTOR cB_Position1 = XMLoadFloat3(&CapsuleBPosition1);
	DirectX::XMVECTOR cB_Position2 = XMLoadFloat3(&CapsuleBPosition2);
	DirectX::XMVECTOR cB_Normal = DirectX::XMVector3Normalize(DirectX::XMVectorSubtract(cB_Position2, cB_Position1));
	DirectX::XMVECTOR cB_LineEndOffset = cB_Normal * CapsuleBRadius;
	DirectX::XMVECTOR b_A = cB_Position1 + cB_LineEndOffset;
	DirectX::XMVECTOR b_B = cB_Position2 - cB_LineEndOffset;

	// vectors between line endpoints:
	DirectX::XMVECTOR v0 = b_A - a_A;
	DirectX::XMVECTOR v1 = b_B - a_A;
	DirectX::XMVECTOR v2 = b_A - a_B;
	DirectX::XMVECTOR v3 = b_B - a_B;

	// squared distances:
	float d0;
	DirectX::XMStoreFloat(&d0, DirectX::XMVector3Dot(v0, v0));
	float d1;
	DirectX::XMStoreFloat(&d1, DirectX::XMVector3Dot(v1, v1));
	float d2;
	DirectX::XMStoreFloat(&d2, DirectX::XMVector3Dot(v2, v2));
	float d3;
	DirectX::XMStoreFloat(&d3, DirectX::XMVector3Dot(v3, v3));

	// select best potential endpoint on capsule A:
	DirectX::XMVECTOR bestA;
	if (d2 < d0 || d2 < d1 || d3 < d0 || d3 < d1)
	{
		bestA = a_B;
	}
	else
	{
		bestA = a_A;
	}

	// select point on capsule B line segment nearest to best potential endpoint on A capsule:
	DirectX::XMVECTOR bestB = ClosestPointOnLineSegment(b_A, b_B, bestA);

	// now do the same for capsule A segment:
	bestA = ClosestPointOnLineSegment(a_A, a_B, bestB);

	DirectX::XMVECTOR penetration_normal = bestA - bestB;
	float len;
	DirectX::XMStoreFloat(&len, DirectX::XMVector3Length(penetration_normal));

	penetration_normal /= len;  // normalize
	float penetration_depth = CapsuleARadius + CapsuleBRadius - len;
	//bool intersects = penetration_depth > 0;
	if (penetration_depth > 0)
	{
		//�������Ă���
		DirectX::XMFLOAT3 best_b;
		DirectX::XMStoreFloat3(&best_b, bestB);
		
		DirectX::XMFLOAT3 hit_nomal;//�q�b�g�ꏊ�ւ̃x�N�g��
		DirectX::XMStoreFloat3(&hit_nomal, penetration_normal * ((CapsuleARadius + CapsuleBRadius) * 0.5f));

		hit_position = DirectX::XMFLOAT3(best_b.x + hit_nomal.x, best_b.y + hit_nomal.y, best_b.z + hit_nomal.z);

		return true;
	}
	else
	{
		//�������Ă��Ȃ�
		return false;
	}
}

//���C�ƃ��f���̌�������
bool Collision::IntersectRayVsModel(const DirectX::XMFLOAT3& start, const DirectX::XMFLOAT3& end, const Model* model, HitResult& result)
{
	////�ȑO�̏����������������悤�ɉ��̎���
	//if (end.y < 0.0f)
	//{
	//	result.position.x = end.x;
	//	result.position.y = 0.0f;
	//	result.position.z = end.z;
	//	result.normal.x = 0.0f;
	//	result.normal.y = 1.0f;
	//	result.normal.z = 0.0f;
	//	return true;
	//}
	//return false;

	DirectX::XMVECTOR WorldStart = DirectX::XMLoadFloat3(&start);
	DirectX::XMVECTOR WorldEnd = DirectX::XMLoadFloat3(&end);
	DirectX::XMVECTOR WorldRayVec = DirectX::XMVectorSubtract(WorldEnd, WorldStart);
	DirectX::XMVECTOR WorldRayLength = DirectX::XMVector3Length(WorldRayVec);

	//���[���h��Ԃ̃��C�̒���
	DirectX::XMStoreFloat(&result.distance, WorldRayLength);

	bool hit = false;
	const ModelResource* resource = model->GetResource();
	for (const ModelResource::Mesh& mesh : resource->GetMeshes())
	{
		//���b�V���m�[�h�擾
		const Model::Node& node = model->GetNodes().at(mesh.nodeIndex);

		//���C�����[���h��Ԃ��烍�[�J����Ԃ֕ϊ�
		DirectX::XMMATRIX WorldTransform = DirectX::XMLoadFloat4x4(&node.worldTransform);
		DirectX::XMMATRIX InverseWorldTransform = DirectX::XMMatrixInverse(nullptr, WorldTransform);

		DirectX::XMVECTOR Start = DirectX::XMVector3TransformCoord(WorldStart, InverseWorldTransform);
		DirectX::XMVECTOR End = DirectX::XMVector3TransformCoord(WorldEnd, InverseWorldTransform);
		DirectX::XMVECTOR Vec = DirectX::XMVectorSubtract(End, Start);
		DirectX::XMVECTOR Dir = DirectX::XMVector3Normalize(Vec);
		DirectX::XMVECTOR Length = DirectX::XMVector3Length(Vec);

		//���C�̒���
		float neart;
		DirectX::XMStoreFloat(&neart, Length);

		//�O�p�`�i�ʁj�Ƃ̌�������
		const std::vector<ModelResource::Vertex>& vertices = mesh.vertices;
		const std::vector<UINT> indices = mesh.indices;

		int materialIndex = -1;
		DirectX::XMVECTOR HitPosition;
		DirectX::XMVECTOR HitNormal;
		for (const ModelResource::Subset& subset : mesh.subsets)
		{
			for (UINT i = 0; i < subset.indexCount; i += 3)
			{
				UINT index = subset.startIndex + i;
				//�O�p�`�̒��_�𒊏o
				const ModelResource::Vertex& a = vertices.at(indices.at(index));
				const ModelResource::Vertex& b = vertices.at(indices.at(index + 1));
				const ModelResource::Vertex& c = vertices.at(indices.at(index + 2));

				DirectX::XMVECTOR A = DirectX::XMLoadFloat3(&a.position);
				DirectX::XMVECTOR B = DirectX::XMLoadFloat3(&b.position);
				DirectX::XMVECTOR C = DirectX::XMLoadFloat3(&c.position);

				//�O�p�`�̎O�Ӄx�N�g�����Z�o
				DirectX::XMVECTOR AB = DirectX::XMVectorSubtract(B, A);
				DirectX::XMVECTOR BC = DirectX::XMVectorSubtract(C, B);
				DirectX::XMVECTOR CA = DirectX::XMVectorSubtract(A, C);

				//�O�p�`�̖@���x�N�g�����Z�o
				DirectX::XMVECTOR Normal = DirectX::XMVector3Cross(AB, BC);

				//���ς̌��ʂ��v���X�Ȃ�Ε\����
				DirectX::XMVECTOR Dot = DirectX::XMVector3Dot(Dir, Normal);
				float dot;
				DirectX::XMStoreFloat(&dot, Dot);
				if (dot >= 0.0f) continue;

				//���C�ƕ��ʂ̌�_���Z�o
				DirectX::XMVECTOR V = DirectX::XMVectorSubtract(A, Start);
				DirectX::XMVECTOR T = DirectX::XMVectorDivide(DirectX::XMVector3Dot(Normal, V), Dot);
				float t;
				DirectX::XMStoreFloat(&t, T);
				if (t < .0f || t > neart) continue;//��_�܂ł̋��������܂łɌv�Z�����ŋߋ������
				                                   //�傫���ꍇ�̓X�L�b�v

				DirectX::XMVECTOR Position = DirectX::XMVectorAdd(DirectX::XMVectorMultiply(Dir, T), Start);

				//��_���O�p�`�̓����ɂ��邩����
				//1��
				DirectX::XMVECTOR V1 = DirectX::XMVectorSubtract(A, Position);
				DirectX::XMVECTOR Cross1 = DirectX::XMVector3Cross(V1, AB);
				DirectX::XMVECTOR Dot1 = DirectX::XMVector3Dot(Cross1, Normal);
				float dot1;
				DirectX::XMStoreFloat(&dot1, Dot1);
				if (dot1 < 0.0f)continue;

				//2��
				DirectX::XMVECTOR V2 = DirectX::XMVectorSubtract(B, Position);
				DirectX::XMVECTOR Cross2 = DirectX::XMVector3Cross(V2, BC);
				DirectX::XMVECTOR Dot2 = DirectX::XMVector3Dot(Cross2, Normal);
				float dot2;
				DirectX::XMStoreFloat(&dot2, Dot2);
				if (dot2 < 0.0f)continue;

				//3��
				DirectX::XMVECTOR V3 = DirectX::XMVectorSubtract(C, Position);
				DirectX::XMVECTOR Cross3 = DirectX::XMVector3Cross(V3, CA);
				DirectX::XMVECTOR Dot3 = DirectX::XMVector3Dot(Cross3, Normal);
				float dot3;
				DirectX::XMStoreFloat(&dot3, Dot3);
				if (dot3 < 0.0f)continue;

				//�ŋߋ������X�V
				neart = t;

				//��_�Ɩ@����@��
				HitPosition = Position;
				HitNormal = Normal;
				materialIndex = subset.materialIndex;
			}
		}
		if(materialIndex >= 0)
		{
			//���[�J����Ԃ��烏�[���h��Ԃ֕ϊ�
			DirectX::XMVECTOR WorldPosition = DirectX::XMVector3TransformCoord(HitPosition, WorldTransform);

			DirectX::XMVECTOR WorldCrossVec = DirectX::XMVectorSubtract(WorldPosition, WorldStart);
			DirectX::XMVECTOR WorldCrossLength = DirectX::XMVector3Length(WorldCrossVec);
			float distance;
			DirectX::XMStoreFloat(&distance, WorldCrossLength);

			//�q�b�g���ۑ�
			if (result.distance > distance)
			{
				DirectX::XMVECTOR WorldNormal = DirectX::XMVector3TransformNormal(HitNormal, WorldTransform);

				result.distance = distance;
				result.material_index = materialIndex;
				DirectX::XMStoreFloat3(&result.position, WorldPosition);
				DirectX::XMStoreFloat3(&result.normal, DirectX::XMVector3Normalize(WorldNormal));
				hit = true;
			}
		}
	}

	return hit;
}

bool Collision::ColliderVsCollider(Collider* collider_A, Collider* collider_B, DirectX::XMFLOAT3& hit_position)
{
	if (collider_A->GetCollisionFlag() && collider_B->GetCollisionFlag())
	{
		if (collider_B->GetShape() == Collider::Shape::Point)
		{
			return collider_A->VsPointCollider(dynamic_cast<PointCollider*>(collider_B), hit_position);
		}
		else if (collider_B->GetShape() == Collider::Shape::Circle)
		{
			return collider_A->VsCircleCollider(dynamic_cast<CircleCollider*>(collider_B), hit_position);
		}
		else if (collider_B->GetShape() == Collider::Shape::Sphere)
		{
			return collider_A->VsSphereCollider(dynamic_cast<SphereCollider*>(collider_B), hit_position);
		}
		else if (collider_B->GetShape() == Collider::Shape::Capsule)
		{
			return collider_A->VsCapsuleCollider(dynamic_cast<CapsuleCollider*>(collider_B), hit_position);
		}
		else if (collider_B->GetShape() == Collider::Shape::Cylinder)
		{
			return collider_A->VsCylinderCollider(dynamic_cast<CylinderCollider*>(collider_B), hit_position);
		}
	}
	return false;
}

bool Collision::ColliderPointVsCircle(PointCollider* point, CircleCollider* circle)
{
	return IntersectPointVsCircle(point->GetPosition(), circle->GetPosition(), circle->GetRadius());
}

bool Collision::ColliderSphereVsSphere(SphereCollider* sphere_A, SphereCollider* sphere_B, DirectX::XMFLOAT3& hit_position)
{
	return IntersectSphereVsSphere(sphere_A->GetPosition(), sphere_A->GetRadius(), sphere_B->GetPosition(), sphere_B->GetRadius(), hit_position);
}

bool Collision::ColliderCapsuleVsCapsule(CapsuleCollider* capsule_A, CapsuleCollider* capsule_B, DirectX::XMFLOAT3& hit_position)
{
	return IntersectCapsuleVsCapsule2(capsule_A->GetPositionA(), capsule_A->GetPositionB(), capsule_A->GetRadiusA(), capsule_B->GetPositionA(), capsule_B->GetPositionB(), capsule_B->GetRadiusA(), hit_position);
}

bool Collision::ColliderCylinderVsCylinder(CylinderCollider* cylinder_A, CylinderCollider* cylinder_B, DirectX::XMFLOAT3& hit_position)
{
	return IntersectCylinderVsCylinder(cylinder_A->GetPosition(), cylinder_A->GetRadius(), cylinder_A->GetHeight(), cylinder_B->GetPosition(), cylinder_B->GetRadius(), cylinder_B->GetHeight(), hit_position);
}

bool Collision::ColliderSphereVsCapsule(SphereCollider* sphere, CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position)
{
	return IntersectSphereVsCapsule(sphere->GetPosition(), sphere->GetRadius(), capsule->GetPositionA(), capsule->GetPositionB(), capsule->GetRadiusA(), hit_position);
}

bool Collision::ColliderSphereVsCylinder(SphereCollider* sphere, CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position)
{
	return IntersectSphereVsCylinder(sphere->GetPosition(), sphere->GetRadius(), cylinder->GetPosition(), cylinder->GetRadius(), cylinder->GetHeight());
}