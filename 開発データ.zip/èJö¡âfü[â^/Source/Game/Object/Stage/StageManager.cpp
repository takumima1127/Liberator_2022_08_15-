#include "StageManager.h"

void StageManager::Initialize()
{
	//���z�u
	{
		SetFloor(DirectX::XMFLOAT3(.0f, .0f, .0f));
		SetFloor(DirectX::XMFLOAT3(.0f, .0f, 1.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, .0f, 2.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, .0f, -1.0f));

		SetFloor(DirectX::XMFLOAT3(1.0f, .0f, .0f));
		SetFloor(DirectX::XMFLOAT3(1.0f, .0f, 1.0f));
		SetFloor(DirectX::XMFLOAT3(1.0f, .0f, 2.0f));
		SetFloor(DirectX::XMFLOAT3(1.0f, .0f, -1.0f));
		
		SetFloor(DirectX::XMFLOAT3(-1.0f, .0f, .0f));
		SetFloor(DirectX::XMFLOAT3(-1.0f, .0f, 1.0f));
		SetFloor(DirectX::XMFLOAT3(-1.0f, .0f, 2.0f));
		SetFloor(DirectX::XMFLOAT3(-1.0f, .0f, -1.0f));


		SetFloor(DirectX::XMFLOAT3(.0f, 1.25f, 3.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 1.25f, 4.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 1.25f, 5.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 1.25f, 6.0f));

		SetFloor(DirectX::XMFLOAT3(.0f, 2.5f, 7.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 2.5f, 8.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 2.5f, 9.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 2.5f, 10.0f));

		SetFloor(DirectX::XMFLOAT3(.0f, 5.0f, 11.0f));

		SetFloor(DirectX::XMFLOAT3(.0f, 5.0f, 12.0f));
		SetFloor(DirectX::XMFLOAT3(1.0f, 5.0f, 12.0f));
		SetFloor(DirectX::XMFLOAT3(-1.0f, 5.0f, 12.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 5.0f, 13.0f));
		SetFloor(DirectX::XMFLOAT3(1.0f, 5.0f, 13.0f));
		SetFloor(DirectX::XMFLOAT3(-1.0f, 5.0f, 13.0f));
		SetFloor(DirectX::XMFLOAT3(.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(1.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(-1.0f, 5.0f, 14.0f));

		SetFloor(DirectX::XMFLOAT3(2.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(3.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(4.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(5.0f, 5.0f, 14.0f));

		SetFloor(DirectX::XMFLOAT3(8.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(9.0f, 5.0f, 14.0f));
		SetFloor(DirectX::XMFLOAT3(9.0f, 5.0f, 15.0f));

		SetFloor(DirectX::XMFLOAT3(9.0f, 6.0f, 18.0f));
		SetFloor(DirectX::XMFLOAT3(10.0f, 6.0f, 18.0f));

		SetFloor(DirectX::XMFLOAT3(15.0f, 3.0f, 18.0f));

		SetFloor(DirectX::XMFLOAT3(16.0f, 3.0f, 16.0f));
		SetFloor(DirectX::XMFLOAT3(16.0f, 3.0f, 17.0f));
		SetFloor(DirectX::XMFLOAT3(16.0f, 3.0f, 18.0f));
		SetFloor(DirectX::XMFLOAT3(16.0f, 3.0f, 19.0f));
		SetFloor(DirectX::XMFLOAT3(16.0f, 3.0f, 20.0f));
		
		SetFloor(DirectX::XMFLOAT3(17.0f, 3.0f, 16.0f));
		SetFloor(DirectX::XMFLOAT3(17.0f, 3.0f, 17.0f));
		SetFloor(DirectX::XMFLOAT3(17.0f, 3.0f, 18.0f));
		SetFloor(DirectX::XMFLOAT3(17.0f, 3.0f, 19.0f));
		SetFloor(DirectX::XMFLOAT3(17.0f, 3.0f, 20.0f));

		SetFloor(DirectX::XMFLOAT3(18.0f, 3.0f, 16.0f));
		SetFloor(DirectX::XMFLOAT3(18.0f, 3.0f, 17.0f));
		SetFloor(DirectX::XMFLOAT3(18.0f, 3.0f, 18.0f));
		SetFloor(DirectX::XMFLOAT3(18.0f, 3.0f, 19.0f));
		SetFloor(DirectX::XMFLOAT3(18.0f, 3.0f, 20.0f));

		SetFloor(DirectX::XMFLOAT3(19.0f, 3.0f, 16.0f));
		SetFloor(DirectX::XMFLOAT3(19.0f, 3.0f, 17.0f));
		SetFloor(DirectX::XMFLOAT3(19.0f, 3.0f, 18.0f));
		SetFloor(DirectX::XMFLOAT3(19.0f, 3.0f, 19.0f));
		SetFloor(DirectX::XMFLOAT3(19.0f, 3.0f, 20.0f));

		SetFloor(DirectX::XMFLOAT3(20.0f, 3.0f, 16.0f));
		SetFloor(DirectX::XMFLOAT3(20.0f, 3.0f, 17.0f));
		SetFloor(DirectX::XMFLOAT3(20.0f, 3.0f, 18.0f));
		SetFloor(DirectX::XMFLOAT3(20.0f, 3.0f, 19.0f));
		SetFloor(DirectX::XMFLOAT3(20.0f, 3.0f, 20.0f));
	}

	//�ǔz�u
	{
		SetWall_B(DirectX::XMFLOAT3(.0f, -2.7f, 3.0f));
		SetWall_B(DirectX::XMFLOAT3(.0f, -1.5f, 7.0f));
		SetWall_B(DirectX::XMFLOAT3(.0f, 1.0f, 11.0f));

		SetWall_B(DirectX::XMFLOAT3(9.0f, 2.0f, 18.0f));

		SetWall_A(DirectX::XMFLOAT3(14.0f, 5.0f, 18.0f));
		
		//SetWall_A(DirectX::XMFLOAT3(-1.0f, .0f, .0f));
		//SetWall_A(DirectX::XMFLOAT3(-1.0f, .0f, 1.0f));
		//SetWall_A(DirectX::XMFLOAT3(-1.0f, .0f, -1.0f));
		//
		//SetWall_A(DirectX::XMFLOAT3(2.0f, .0f, .0f));
		//SetWall_A(DirectX::XMFLOAT3(2.0f, .0f, 1.0f));
		//SetWall_A(DirectX::XMFLOAT3(2.0f, .0f, -1.0f));
		//
		//SetWall_B(DirectX::XMFLOAT3(.0f, .0f, 2.0f));
		//SetWall_B(DirectX::XMFLOAT3(1.0f, .0f, 2.0));
		//SetWall_B(DirectX::XMFLOAT3(-1.0f, .0f, 2.0f));
		//
		//SetWall_B(DirectX::XMFLOAT3(.0f, .0f, -1.0f));
		//SetWall_B(DirectX::XMFLOAT3(1.0f, .0f, -1.0));
		//SetWall_B(DirectX::XMFLOAT3(-1.0f, .0f, -1.0f));
		
		//
		//SetWall(DirectX::XMFLOAT3(.0f, .0f, .0f));
		//SetWall(DirectX::XMFLOAT3(.0f, .0f, .0f));
		//SetWall(DirectX::XMFLOAT3(.0f, .0f, .0f));
		//SetWall(DirectX::XMFLOAT3(.0f, .0f, .0f));
	}

	//StageFloor_01* stage_floor_01 = new StageFloor_01();
	//stage_floor_01->Initialize(DirectX::XMFLOAT3(DirectX::XMFLOAT3(.0f, .0f, .0f)));
	//Register(stage_floor_01);
	//
	//StageFloor_01* stage_floor_02 = new StageFloor_01();
	//stage_floor_02->Initialize(DirectX::XMFLOAT3(DirectX::XMFLOAT3(1.0f, .0f, .0f)));
	//Register(stage_floor_02);

	//StageMoveFloor* stageMoveFloor = new StageMoveFloor();
	//stageMoveFloor->SetStartPoint(DirectX::XMFLOAT3(0, 1, 3));
	//stageMoveFloor->SetGoalPoint(DirectX::XMFLOAT3(10, 2, 3));
	//stageMoveFloor->SetTorque(DirectX::XMFLOAT3(0, 1.0f, 0));
	//Register(stageMoveFloor);
}

//�X�V����
void StageManager::Update(float elapsed_time)
{
	for (Stage* stage : stages)
	{
		stage->Update(elapsed_time);
	}
}

//�`�揈��
void StageManager::Render(ID3D11DeviceContext* dc, Shader* shader)
{
	for (Stage* stage : stages)
	{
		stage->Render(dc, shader);
	}
}

void StageManager::Set(DirectX::XMFLOAT3 position)
{
	////�ėp���d��(Stage�p���N���X�Ȃ�ǂ�ł�������)
	//{
	//	stages.emplace_back();
	//	int size = stages.size();
	//	stages[size - 1] = new StageFloor_01();
	//	stages[size - 1]->Initialize(position, DirectX::XMFLOAT3(.0f, .0f, .0f), stages[size - 1]->GetResizeScale());
	//
	//	stages.emplace_back(stages[size - 1]);
	//}
	
	////std::vector���p
	//{
	//	 stage_floors.emplace_back();
	//	 int size = stage_floors.size();
	//	 stage_floors[size - 1] = new StageFloor_01();
	//	 stage_floors[size - 1]->Initialize(position);
	//	 
	//	 stages.emplace_back(stage_floors[size - 1]);
	//}

	//�y�ʐ��d���H�i������������S�z)
	{
		//stage_floor = new StageFloor_01();
		//stage_floor->Initialize(position);
		//stages.emplace_back(stage_floor);
		////delete stage_floor;
	}

}

void StageManager::SetFloor(DirectX::XMFLOAT3 position)
{
	//���|�C���^�g�p
	{
		stage_floor = new StageFloor_01();
		stage_floor->Initialize(position);
		stages.emplace_back(stage_floor);
	}

	//���j�[�N�|�C���^�g�p
	{
	//	stage_floor = std::make_unique<StageFloor_01>();
	//	stage_floor->Initialize(position);
	//	stages.emplace_back(std::move(stage_floor.get()));
	//	stage_floor.reset();
	}
}

void StageManager::SetWall_A(DirectX::XMFLOAT3 position)
{
	stage_wall = new StageWall_01();
	stage_wall->Initialize(position);
	stages.emplace_back(stage_wall);
}

void StageManager::SetWall_B(DirectX::XMFLOAT3 position)
{
	stage_wall = new StageWall_01();
	stage_wall->Initialize(position, DirectX::XMFLOAT3(.0f, DirectX::XMConvertToRadians(90.0f), .0f));
	stages.emplace_back(stage_wall);
}

//�X�e�[�W�o�^
void StageManager::Register(Stage* stage)
{
	stages.emplace_back(stage);
}

//�X�e�[�W�S�폜
void StageManager::Clear()
{
	for (Stage* stage : stages)
	{
		delete stage;
	}
	stages.clear();

	//stage_floor.reset();
}

//���C�L���X�g
bool StageManager::RayCast(const DirectX::XMFLOAT3& start, const DirectX::XMFLOAT3& end, HitResult& hit)
{
	bool result = false;
	hit.distance = FLT_MAX;

	for (Stage* stage : stages)
	{
		HitResult tmp;
		if (stage->RayCast(start, end, tmp))
		{
			if (hit.distance > tmp.distance)
			{
				hit = tmp;
				result = true;
			}
		}
	}
	return result;
}
