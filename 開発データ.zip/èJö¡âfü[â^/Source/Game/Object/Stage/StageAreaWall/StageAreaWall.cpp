#include "Game/Object/Stage/Stage.h"
#include "StageAreaWall.h"
#include "Game/Light/Light.h"
#include "Game/Camera/Camera.h"
#include "Graphics/Texture/Texture.h"
#include "Graphics/Shader/Mesh/ScrollMesh/ScrollMesh.h"

StageAreaWall::StageAreaWall()
{
	//�X�e�[�W���f����ǂݍ���
	//model = new Model("Data/Model/Stage/Wall_Plain.mdl");
	scroll_texture = std::make_unique<Texture>();
	scroll_texture->Load(L"Data/Sprite/Load/line.png");


	mesh = std::make_unique<ScrollMesh>(ScrollMesh::Type::QuadTriangle, scroll_texture, DirectX::XMFLOAT3(.0f, .0f, .0f), DirectX::XMFLOAT3(1.0f, 1.0f, 1.0f), DirectX::XMFLOAT2(0.5f, 0.1f));

	//�I�t�Z�b�g�l�Z�b�g
	SetOffsetPosition(DirectX::XMFLOAT3(.0f, .0f, .0f));
	SetOffsetScale(DirectX::XMFLOAT3(12.0f, 4.6f, 12.0f));
	SetScale(DirectX::XMFLOAT3(resize_scale));
}

StageAreaWall::~StageAreaWall()
{
}

void StageAreaWall::Initialize(DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 angle, DirectX::XMFLOAT3 scale)
{
	SetPosition(DirectX::XMFLOAT3(position.x * offset_scale.x, position.y * offset_scale.y, position.z * offset_scale.z));
	SetAngle(angle);

	UpdateTransform();//���[���h�s��쐬
}

void StageAreaWall::Update(float elapsed_time)
{
	mesh->Update(elapsed_time);
}

void StageAreaWall::Render(ID3D11DeviceContext* dc, Shader* shader)
{	
	// �`�揈��
	RenderContext rc;
	rc.lightDirection = Light::LightDir;	// ���C�g�����i�������j

	//�J�����p�����[�^�ݒ�
	Camera& camera = Camera::GetInstance();
	rc.view = camera.GetView();
	rc.projection = camera.GetProjection();


	//�V�F�[�_�[�Ƀ��f����`�悵�Ă��炤
	mesh->Render(dc, rc,
		1.0f, 1.0f, 1.0f, 1.0f);
}

//bool StageAreaWall::RayCast(const DirectX::XMFLOAT3& start, const DirectX::XMFLOAT3& end, HitResult& hit)
//{
//	return Collision::IntersectRayVsModel(start, end, model, hit);
//}