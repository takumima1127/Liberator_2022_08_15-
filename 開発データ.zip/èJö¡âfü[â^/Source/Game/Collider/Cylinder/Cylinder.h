#pragma once
#include "Game/Collider/Collider.h"
//��
class CylinderCollider : public Collider
{
public:
	CylinderCollider(const char* name, DirectX::XMFLOAT3* position, float radius, float height, int priority, bool collision_flag, Element element = Element::Norn);
	~CylinderCollider() {};

	//�X�V����
	void Update(float elapsed_time);
	//�f�o�b�O�pGUI�`��
	void DrawDebugPrimitive() override;

public:
	//�Q�b�^�[
	DirectX::XMFLOAT3& GetPosition() { return *position; }
	float GetRadius() const { return radius; }
	float GetHeight() const { return height; }

	bool VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position) override;
	bool VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position) override;
	bool VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position) override;
	bool VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position) override;
	bool VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position) override;
protected:
	DirectX::XMFLOAT3* position;//�ʒu
	float radius;//���a
	float height;//����
};