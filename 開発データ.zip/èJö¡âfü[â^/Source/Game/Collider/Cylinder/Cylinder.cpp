#include "Cylinder.h"
#include "Graphics/Graphics.h"
#include "Game/Collision/Collision.h"

CylinderCollider::CylinderCollider(const char* name, DirectX::XMFLOAT3* position, float radius, float height, int priority, bool collision_flag, Element element)
{
	this->hash = std::make_unique<Hash>(name);
	shape = Shape::Cylinder;
	this->element = element;
	this->position = position;
	this->radius = radius;
	this->height = height;
	this->collision_flag = collision_flag;
	this->priority = priority;
}

void CylinderCollider::Update(float elapsed_time)
{
}

void CylinderCollider::DrawDebugPrimitive()
{
	Collider::DrawDebugPrimitive();
	DebugRenderer* debugRenderer = Graphics::Instance().GetDebugRenderer();

	debugRenderer->DrawCylinder(DirectX::XMFLOAT3(position->x, position->y, position->z), radius, height, debug_color);
}

bool CylinderCollider::VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CylinderCollider::VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CylinderCollider::VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderSphereVsCylinder(sphere, this, hit_position);
}

bool CylinderCollider::VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CylinderCollider::VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderCylinderVsCylinder(this, cylinder, hit_position);
}
