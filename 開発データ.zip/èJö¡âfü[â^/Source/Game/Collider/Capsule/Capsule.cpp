#include "Capsule.h"
#include "Graphics/Graphics.h"
#include "Game/Collision/Collision.h"

CapsuleCollider::CapsuleCollider(const char* name, DirectX::XMFLOAT3* position_A, DirectX::XMFLOAT3* position_B, float radius_A, float radius_B, int priority, bool collision_flag,  Element element)
{
	this->hash = std::make_unique<Hash>(name);
	shape = Shape::Capsule;
	this->element = element;
#if 0
	this->position_A.reset(position_A);
	this->position_B.reset(position_B);
#else
	this->position_A = position_A;
	this->position_B = position_B;

#endif
	this->radius_A = radius_A;
	this->radius_B = radius_B;

	this->collision_flag = collision_flag;
	//this->is_trigger = is_trigger;
	this->priority = priority;
}

void CapsuleCollider::Update(float elapsed_time)
{
}

void CapsuleCollider::DrawDebugPrimitive()
{
	Collider::DrawDebugPrimitive();

	DebugRenderer* debugRenderer = Graphics::Instance().GetDebugRenderer();
	debugRenderer->DrawSphere(DirectX::XMFLOAT3(
		position_A->x,
		position_A->y,
		position_A->z),
		radius_A,
		DirectX::XMFLOAT4(debug_color));
	
	debugRenderer->DrawSphere(DirectX::XMFLOAT3(
		position_B->x,
		position_B->y,
		position_B->z),
		radius_B,
		DirectX::XMFLOAT4(debug_color));

}

bool CapsuleCollider::VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CapsuleCollider::VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CapsuleCollider::VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderSphereVsCapsule(sphere, this, hit_position);
}

bool CapsuleCollider::VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderCapsuleVsCapsule(this, capsule, hit_position);
}

bool CapsuleCollider::VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position)
{
	return false;
}
