#pragma once
#include "Game/Collider/Collider.h"
//��
class CapsuleCollider : public Collider
{
public:
	CapsuleCollider(const char* name, DirectX::XMFLOAT3* position_A, DirectX::XMFLOAT3* position_B, float radius_A, float radius_B, int priority, bool collision_flag, Element element = Element::Norn);
	~CapsuleCollider() {};

	//�X�V����
	void Update(float elapsed_time);
	//�f�o�b�O�pGUI�`��
	void DrawDebugPrimitive() override;

public:
	//�Q�b�^�[
	DirectX::XMFLOAT3& GetPositionA() { return  *position_A; }
	DirectX::XMFLOAT3& GetPositionB() { return  *position_B; }
	float GetRadiusA() const { return radius_A; }
	float GetRadiusB() const { return radius_B; }

	bool VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
private:
	DirectX::XMFLOAT3* position_A;//�ʒu
	DirectX::XMFLOAT3* position_B;//�ʒu
	float radius_A;
	float radius_B;
};