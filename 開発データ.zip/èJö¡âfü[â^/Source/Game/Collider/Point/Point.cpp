#include "Game/Collider/Point/Point.h"
#include "Graphics/Graphics.h"
#include "Game/Collision/Collision.h"

PointCollider::PointCollider(const char* name, DirectX::XMFLOAT3* position, int priority, bool collision_flag, Element element)
{
	this->hash = std::make_unique<Hash>(name);
	shape = Shape::Point;
	this->element = element;

#if 0
	this->position.reset(position);
#else
	this->position = position;
#endif
	this->collision_flag = collision_flag;
	this->priority = priority;
}

void PointCollider::Update(float elapsed_time)
{
}

void PointCollider::DrawDebugPrimitive()
{
	Collider::DrawDebugPrimitive();

	DebugRenderer* debugRenderer = Graphics::Instance().GetDebugRenderer();
	debugRenderer->DrawSphere(DirectX::XMFLOAT3(position->x, position->y, position->z), 1.0f, debug_color);
}

bool PointCollider::VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool PointCollider::VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool PointCollider::VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool PointCollider::VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool PointCollider::VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position)
{
	return false;
}
