#pragma once
#include "Game/Collider/Collider.h"
//��
class PointCollider : public Collider
{
public:
	PointCollider(const char* name, DirectX::XMFLOAT3* position, int priority, bool collision_flag, Element element = Element::Norn);
	~PointCollider() {};

	//�X�V����
	void Update(float elapsed_time);
	//�f�o�b�O�pGUI�`��
	void DrawDebugPrimitive() override;

public:
	//�Q�b�^�[
	DirectX::XMFLOAT3& GetPosition() { return *position; }

	bool VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
private:
#if 1
	DirectX::XMFLOAT3* position;//�ʒu
#else
	std::shared_ptr<DirectX::XMFLOAT3> position = nullptr;//�ʒu
#endif
};