#include "Collider.h"

Collider::Collider()
{
	
}

void Collider::DrawDebugPrimitive()
{
	debug_draw_function_array[element]();
}

void Collider::DrawCollider()
{
	if (collision_flag)
	{
		debug_color = debug_coloer_array[DebugColoer::Default];
	}
	else
	{
		debug_color = debug_coloer_array[DebugColoer::Default];
	}
}

void Collider::DrawAttackCollider()
{
	if(collision_flag)
	{
		debug_color = debug_coloer_array[DebugColoer::Attack_True];
	}
	else
	{
		debug_color = debug_coloer_array[DebugColoer::Attack_False];
	}
}

void Collider::DrawDamageCollider()
{
	if (collision_flag)
	{
		debug_color = debug_coloer_array[DebugColoer::Damage_True];
	}
	else
	{
		debug_color = debug_coloer_array[DebugColoer::Damage_False];
	}

}

void Collider::DrawPushCollider()
{
	if (collision_flag)
	{
		debug_color = debug_coloer_array[DebugColoer::Push_True];
	}
	else
	{
		debug_color = debug_coloer_array[DebugColoer::Push_False];
	}
}
