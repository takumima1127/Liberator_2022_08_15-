#include "Sphere.h"
#include "Graphics/Graphics.h"
#include "Game/Collision/Collision.h"

SphereCollider::SphereCollider(const char* name, DirectX::XMFLOAT3* position, float radius, int priority, bool collision_flag, Element element)
{
	this->hash = std::make_unique<Hash>(name);
	shape = Shape::Sphere;
	this->element = element;

#if 1
	this->position = position;

#else
	this->position = std::make_shared<DirectX::XMFLOAT3>();
	this->position.reset(position);

#endif
	
	this->radius = radius;
	this->collision_flag = collision_flag;
	//this->is_trigger = is_trigger;
	this->priority = priority;
}

void SphereCollider::Update(float elapsed_time)
{

}

void SphereCollider::DrawDebugPrimitive()
{
	Collider::DrawDebugPrimitive();

	DebugRenderer* debugRenderer = Graphics::Instance().GetDebugRenderer();

	debugRenderer->DrawSphere(DirectX::XMFLOAT3(
		position->x,
		position->y,
		position->z),
		radius,
		debug_color);
}

bool SphereCollider::VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool SphereCollider::VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool SphereCollider::VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderSphereVsSphere(this, sphere, hit_position);
}

bool SphereCollider::VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderSphereVsCapsule(this, capsule, hit_position);
}

bool SphereCollider::VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position)
{
	return Collision::ColliderSphereVsCylinder(this, cylinder, hit_position);
}
