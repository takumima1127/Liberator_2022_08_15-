#pragma once
#include "Game/Collider/Collider.h"
//��
class CircleCollider : public Collider
{
public:
	CircleCollider(const char* name, DirectX::XMFLOAT3* position, float radius, int priority, bool collision_flag, Element element = Element::Norn);
	~CircleCollider() {};

	//�X�V����
	void Update(float elapsed_time);
	//�f�o�b�O�pGUI�`��
	void DrawDebugPrimitive() override;

public:
	//�Q�b�^�[
	DirectX::XMFLOAT3& GetPosition() { return *position; }
	float GetRadius() const { return radius; }

	bool VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
	bool VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position = DirectX::XMFLOAT3(0, 0, 0)) override;
private:
	DirectX::XMFLOAT3* position;//�ʒu
	float radius;//���a
};