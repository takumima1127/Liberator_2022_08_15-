#include "Circle.h"
#include "Graphics/Graphics.h"
#include "Game/Collision/Collision.h"

CircleCollider::CircleCollider(const char* name, DirectX::XMFLOAT3* position, float radius, int priority, bool collision_flag, Element element)
{
	this->hash = std::make_unique<Hash>(name);
	shape = Shape::Circle;
	this->element = element;

#if 0
	this->position.reset(position);
#else
	this->position = position;
#endif
	this->radius = radius;
	this->collision_flag = collision_flag;
	this->priority = priority;
}

void CircleCollider::Update(float elapsed_time)
{
}

void CircleCollider::DrawDebugPrimitive()
{
	Collider::DrawDebugPrimitive();
	DebugRenderer* debugRenderer = Graphics::Instance().GetDebugRenderer();
	debugRenderer->DrawCylinder(DirectX::XMFLOAT3(position->x, position->y, position->z), radius, 1.0f, debug_color);
}

bool CircleCollider::VsPointCollider(PointCollider* point, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CircleCollider::VsCircleCollider(CircleCollider* circle, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CircleCollider::VsSphereCollider(SphereCollider* sphere, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CircleCollider::VsCapsuleCollider(CapsuleCollider* capsule, DirectX::XMFLOAT3& hit_position)
{
	return false;
}

bool CircleCollider::VsCylinderCollider(CylinderCollider* cylinder, DirectX::XMFLOAT3& hit_position)
{
	return false;
}
