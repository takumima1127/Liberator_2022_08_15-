#pragma once

#include <DirectXMath.h>
#include <Effekseer.h>
#include <EffekseerRendererDX11.h>
#include "Effect.h"
#include "Singleton/Singleton.h"

//�G�t�F�N�g�}�l�[�W���[
class EffectManager : public Singleton<EffectManager>
{
public:
	EffectManager() {}
	~EffectManager() {}

public:
	//�X�e�[�g
	enum class EffectNumber
	{
		Spark01,
		Spark02,
		Blow01,
		Guard01,
		Damage01,
		Counter01,
		Jump01,
		WallJump01,
		Accumulate01,
		Accumulate02,
		Down01,
		Glide01,
		Heal,
		Revival
	};

private:
	std::map < EffectNumber, std::shared_ptr<Effect>> effect_array;

public:
	////�B��̃C���X�^���X�擾
	//static EffectManager& GetInstance()
	//{
	//	static EffectManager instance;
	//	return instance;
	//}

	//������
	void Initialize();

	//�I����
	void Finalize();

	//�X�V����
	void Update(float elapsed_time);

	//�`�揈��
	void Render(const DirectX::XMFLOAT4X4& view, const DirectX::XMFLOAT4X4& projection);

	//�Đ�
	void Play(EffectNumber EffectNum, const DirectX::XMFLOAT3& position, const DirectX::XMFLOAT3& angle, float scale = 1.0f, float begin_time = .0f);

	//�G�t�F�N�g�Q�b�^�[
	Effect* GetEffect(EffectNumber EffectNum);

	//Effeckseer�}�l�[�W���[�̎擾
	Effekseer::Manager* GetEffekseerManager() { return effekseer_manager; }

private:
	Effekseer::Manager* effekseer_manager = nullptr;
	EffekseerRenderer::Renderer* effekseer_renderer = nullptr;
};