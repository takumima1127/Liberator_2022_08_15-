#include "AttackData.h"

void AttackData::SetCollisionDataArraySize(int size)
{
	collision_data_array.resize(size);
}

void AttackData::SetCollisionData(const char* collider_name, uint32_t collider_hash, int damage, float begin_collision_time, float end_collision_time)
{
	AttackCollisionData collision_data = { collider_name, collider_hash, damage, begin_collision_time, end_collision_time };
	collision_data_array.emplace_back(collision_data);
}