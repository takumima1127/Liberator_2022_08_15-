#include "EnemyAttackData.h"

void EnemyAttackData::Initialize(int hit_max)
{
	this->hit_max = hit_max;
	collision_data_array.resize(hit_max);
}

void EnemyAttackData::CollisionFlagInit()
{
	for (int i = 0; i < static_cast<int>(collision_data_array.size()); i++)
	{
		//����t���O������
		collision_data_array[i].collision_flag = EnemyAttackData::AttackCollisionFlag::Before;
	}
}

//void EnemyAttackData::SetCollisionDataArraySize(int size)
//{
//	collision_data_array.resize(size);
//}
//
//void EnemyAttackData::SetCollisionData(const char* collider_name, uint32_t collider_hash, int iterator, int damage, float begin_collision_time, float end_collision_time)
//{
//	collision_data_array[iterator].collider_name = collider_name;
//	collision_data_array[iterator].collider_hash = collider_hash;
//	collision_data_array[iterator].damage = damage;
//	collision_data_array[iterator].begin_collision_time = begin_collision_time;
//	collision_data_array[iterator].end_collision_time = end_collision_time;
//}
