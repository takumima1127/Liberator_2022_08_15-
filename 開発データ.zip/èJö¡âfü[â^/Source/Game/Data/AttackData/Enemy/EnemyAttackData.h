#pragma once
#include <DirectXMath.h>
#include <map>
#include <vector>
#include <memory>
#include <string>
#include "Hash/Hash.h"
#include "Game/Data/AttackData/AttackData.h"

class EnemyAttackData : public AttackData
{
public:
	EnemyAttackData() {};
	~EnemyAttackData() {};
	void Initialize(int hit_max);
	void CollisionFlagInit() override;//����t���O������
};
