#pragma once
#include <vector>
#include <memory>
#include <string>

#include "Hash/Hash.h"

class AttackData
{
public:
	AttackData() {};
	~AttackData() {};

	virtual void CollisionFlagInit() {};//����t���O������

	enum class AttackCollisionFlag
	{
		Before,
		True,
		Affter
	};

	struct AttackCollisionData
	{
		const char* collider_name = nullptr;
		uint32_t collider_hash = 0xffffffff;
		int damage = 0;
		float begin_collision_time = .0f;
		float end_collision_time = .0f;
		AttackCollisionFlag collision_flag = AttackCollisionFlag::Before;
	};

public:
	//�Q�b�^�[
	uint32_t GetColliderName(int iterator) { return collision_data_array[iterator].collider_hash; }
	const int GetDamage(int iterator) const { return collision_data_array[iterator].damage; }
	const float GetBeginCollisionTime(int iterator) const { return collision_data_array[iterator].begin_collision_time; }
	const float GetEndCollisionTime(int iterator) const { return collision_data_array[iterator].end_collision_time; }
	const AttackCollisionFlag GetCollisionFlag(int iterator) const { return collision_data_array[iterator].collision_flag; }
	const int GetHitMax() const { return hit_max; }

	std::vector<AttackCollisionData> GetCollisionDataArray() { return collision_data_array; }
	void SetCollisionDataArraySize(int size);

	//�Z�b�^�[
	void SetHitMax() { hit_max = static_cast<int>(collision_data_array.size()); }

	void SetCollisionFlag(int iterator, AttackCollisionFlag flag) { collision_data_array[iterator].collision_flag = flag; }
	void SetCollisionData(const char* collider_name, uint32_t collider_hash, int damage, float begin_collision_time, float end_collision_time);
protected:
	//�����o�ϐ�
	int hit_max = 0;
	std::vector<AttackCollisionData> collision_data_array;
};
