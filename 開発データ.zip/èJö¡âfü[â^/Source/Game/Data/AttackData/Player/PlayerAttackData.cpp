#include "PlayerAttackData.h"

//PlayerAttackData::PlayerAttackData(float cancel_time)
//{
//	this->cancel_time = cancel_time;
//}

void PlayerAttackData::Initialize(float cancel_time, float power, int hit_max, float begin_trajectory_time, float end_trajectory_time)
{
	this->cancel_time = cancel_time;
	this->power = power;
	this->hit_max = hit_max;
	this->begin_trajectory_time = begin_trajectory_time;
	this->end_trajectory_time = end_trajectory_time;
	collision_data_array.resize(hit_max);
}
void PlayerAttackData::CollisionFlagInit()
{
	for (int i = 0; i < static_cast<int>(collision_data_array.size()); i++)
	{
		//����t���O������
		collision_data_array[i].collision_flag = PlayerAttackData::AttackCollisionFlag::Before;
	}
}
//void PlayerAttackData::SetCollisionDataArraySize(int size)
//{
//	collision_data_array.resize(size);
//}
//
//void PlayerAttackData::SetCollisionData(const char* collider_name, uint32_t collider_hash, int damage, float begin_collision_time, float end_collision_time)
//{
//#if false
//	collision_data_array[iterator].collider_name = collider_name;
//	collision_data_array[iterator].collider_hash = collider_hash;
//	collision_data_array[iterator].damage = damage;
//	collision_data_array[iterator].begin_collision_time = begin_collision_time;
//	collision_data_array[iterator].end_collision_time = end_collision_time;
//#else
//	AttackCollisionData collision_data = { collider_name, collider_hash, damage, begin_collision_time, end_collision_time};
//	collision_data_array.emplace_back(collision_data);
//#endif
//}
