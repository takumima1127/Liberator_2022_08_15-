#pragma once
#include <DirectXMath.h>
#include <map>
#include <vector>
#include <memory>
#include <string>
#include "Game/Data/AttackData/AttackData.h"
#include "Hash/Hash.h"

class PlayerAttackData : public AttackData
{
public:
	PlayerAttackData() {};
	//PlayerAttackData(float cancel_time);
	~PlayerAttackData() {};
	void Initialize(float cancel_time, float power, int hit_max, float begin_trajectory_time, float end_trajectory_time);
	void CollisionFlagInit() override;//����t���O������

public:
	//�Q�b�^�[
	const float GetCancelTime() const { return cancel_time; }
	const float GetPower() const { return power; }
	const float GetBeginTrajectoryTime() const { return begin_trajectory_time; }
	const float GetEndTrajectoryTime() const { return end_trajectory_time; }

	//�Z�b�^�[
	void SetCancelTime(float cancel_time) { this->cancel_time = cancel_time; }
	void SetPower(float power) { this->power = power; }
	void SetBeginTrajectoryTime(float begin_trajectory_time) { this->begin_trajectory_time = begin_trajectory_time; }
	void SetEndTrajectoryTime(float end_trajectory_time) { this->end_trajectory_time = end_trajectory_time; }


private:
	//�����o�ϐ�
	float cancel_time = .0f;
	float power = 1.0f;//�U���{��
	float begin_trajectory_time = .0f;
	float end_trajectory_time = .0f;
public:
};
