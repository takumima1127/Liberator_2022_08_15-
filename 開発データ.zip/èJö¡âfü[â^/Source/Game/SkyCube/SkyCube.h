#pragma once
#include <wrl.h>
#include <d3d11.h>
#include <DirectXMath.h>
#include "Graphics/Shader/Shader.h"
#include "Graphics/Texture/Texture.h"
#include "Graphics/Shader/Mesh/CubeMesh/CubeMeshShader.h"
#include "Graphics/Shader/Mesh/CubeMesh/CubeMeshScrollShader.h"

// �X�v���C�g
class SkyCube
{
public:
	SkyCube(std::shared_ptr<Texture> tex, std::shared_ptr<Texture> scroll_tex, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 scale, DirectX::XMFLOAT2 scroll);
	~SkyCube() {}
	void Update(float elapsed_time);
	void Render(ID3D11DeviceContext* dc,
		const RenderContext& rc,
		float r, float g, float b, float a);

private:
	std::unique_ptr<CubeMeshShader> cube = nullptr;//�X�J�C�L���[�u
	std::unique_ptr<CubeMeshScrollShader> scroll_cube = nullptr;//�X�J�C�L���[�u(�X�N���[������w�i)

private:
	DirectX::XMFLOAT2 scroll;
};