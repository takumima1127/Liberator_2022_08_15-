#include "SkyCube.h"
#include <stdio.h> 
#include <WICTextureLoader.h>
#include "Game/Misc/Misc.h"
#include "Graphics/Graphics.h"

SkyCube::SkyCube(std::shared_ptr<Texture> tex, std::shared_ptr<Texture> scroll_tex, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 scale, DirectX::XMFLOAT2 scroll)
{
	cube = std::make_unique<CubeMeshShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f));
	scroll_cube = std::make_unique<CubeMeshScrollShader>(scroll_tex, position, DirectX::XMFLOAT3(scale.x * 1.1f, scale.y * 1.1f, scale.z * 1.1f), scroll);
}

void SkyCube::Update(float elapsed_time)
{
	scroll_cube->Update(elapsed_time);
}

void SkyCube::Render(ID3D11DeviceContext* dc, const RenderContext& rc, float r, float g, float b, float a)
{
#if 0
	cube->Render(dc, rc,1.0f, 1.0f, 1.0f, 1.0f);
	scroll_cube->Render(dc, rc,1.0f, 1.0f, 1.0f, 1.0f);

#else
	scroll_cube->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);
	cube->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

#endif
}