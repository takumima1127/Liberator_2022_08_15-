#include "SkyTunnel.h"
#include <stdio.h> 
#include <WICTextureLoader.h>
#include "Game/Misc/Misc.h"
#include "Graphics/Graphics.h"

SkyTunnel::SkyTunnel(std::shared_ptr<Texture> tex, std::shared_ptr<Texture> scroll_tex, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 scale, DirectX::XMFLOAT2 scroll)
{	
	tunnel = std::make_unique<TunnelMeshShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f));
	scroll_tunnel1 = std::make_unique<TunnelMeshScrollShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f), scroll);
	scroll_tunnel2 = std::make_unique<TunnelMeshScrollShader>(scroll_tex, position, DirectX::XMFLOAT3(scale.x * 1.1f, scale.y * 1.1f, scale.z * 1.1f), scroll);
}

SkyTunnel::SkyTunnel(std::shared_ptr<Texture> tex, std::shared_ptr<Texture> scroll_tex, DirectX::XMFLOAT3 position, DirectX::XMFLOAT3 scale, DirectX::XMFLOAT2 scroll1, DirectX::XMFLOAT2 scroll2)
{
	tunnel = std::make_unique<TunnelMeshShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f));
	scroll_tunnel1 = std::make_unique<TunnelMeshScrollShader>(tex, position, DirectX::XMFLOAT3(scale.x * 1.0f, scale.y * 1.0f, scale.z * 1.0f), scroll1);
	scroll_tunnel2 = std::make_unique<TunnelMeshScrollShader>(scroll_tex, position, DirectX::XMFLOAT3(scale.x * 1.1f, scale.y * 1.1f, scale.z * 1.1f), scroll2);
}

void SkyTunnel::Update(float elapsed_time)
{
	scroll_tunnel1->Update(elapsed_time);
	scroll_tunnel2->Update(elapsed_time);
}

void SkyTunnel::Render(ID3D11DeviceContext* dc, const RenderContext& rc, float r, float g, float b, float a)
{
#if 0
	Tunnel->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);
	scroll_Tunnel->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

#else
	scroll_tunnel2->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);
	scroll_tunnel1->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

	//tunnel->Render(dc, rc, 1.0f, 1.0f, 1.0f, 1.0f);

#endif
}