#include "Game/Scene/SceneManager.h"
#include "Game/Scene/SceneTitle/SceneTitle.h"
#include "Game/Scene/SceneGame/SceneGame.h"
#include "Game/Scene/SceneLoading/SceneLoading.h"

void ChangeSceneTitle()
{
	SceneManager::GetInstance().ChangeScene(new SceneLoading(new SceneTitle));
}

void ChangeSceneGame()
{
	SceneManager::GetInstance().ChangeScene(new SceneLoading(new SceneGame));
}

SceneManager::SceneManager()
{
	scene_array =
	{
		{SceneType::Title, ChangeSceneTitle},
		{SceneType::Game, ChangeSceneGame}
	};
}

//�X�V����
void SceneManager::Update(float elapsed_time)
{
	if (current_scene != nullptr)
	{
		current_scene->Update(elapsed_time);
	}
}

//�`�揈��
void SceneManager::Render()
{
	if (current_scene != nullptr)
	{
		current_scene->Render();
	}
}

//�V�[���N���A
void SceneManager::Clear()
{
	if (current_scene != nullptr)
	{
		current_scene->Finalize();
		delete current_scene;
		current_scene = nullptr;
	}
}

//�V�[���؂�ւ�
void SceneManager::ChangeScene(SceneType scene_type)
{
	//scene_array.at(scene_type);
	scene_array[scene_type]();
}

//�V�[���؂�ւ�
void SceneManager::ChangeScene(Scene* scene)
{
	//�Â��V�[�����I������
	Clear();

	//�V�����V�[����ݒ�
	current_scene = scene;

	//�V�[��������
	if (!current_scene->IsReady())
	{
		current_scene->Initialize();
	}
}

void SceneManager::SetScene(SceneType scene_id)
{
	current_scene->SetScene(static_cast<int>(scene_id));
}

Scene::FilterFlag SceneManager::GetFilterFlag()
{
	return current_scene->GetFilterFlag();
}

void SceneManager::SetFilterFlag(Scene::FilterFlag filter_flag)
{
	current_scene->SetFilterFlag(filter_flag);
}
