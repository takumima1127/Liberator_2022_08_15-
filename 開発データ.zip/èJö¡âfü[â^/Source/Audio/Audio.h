#pragma once

#include <xaudio2.h>
#include "Audio/AudioSource/AudioSource.h"
#include "Singleton/Singleton.h"

// �I�[�f�B�I
class Audio : public Singleton<Audio>
{
public:
	Audio();
	~Audio();

public:
	//// �C���X�^���X�擾
	//static Audio& GetInstance()
	//{
	//	static Audio instance;
	//	return instance;
	//}

	// �I�[�f�B�I�\�[�X�ǂݍ���
	std::unique_ptr<AudioSource> LoadAudioSource(const char* filename, bool loop);

private:
	IXAudio2*				xaudio = nullptr;
	IXAudio2MasteringVoice* masteringVoice = nullptr;
};
